from flask import Flask
import requests

app = Flask(__name__)

@app.route("/")
def inicio():
    return """
    <h1>🐳 Mi aplicación con Docker</h1>
    <p>Esta aplicación utiliza Python, Flask y Requests.</p>
    """

@app.route("/info")
def info():
    respuesta = requests.get("https://api.github.com")

    return f"""
    <h1>Información</h1>
    <p>La aplicación pudo conectarse a GitHub.</p>
    <p>Estado de la respuesta: {respuesta.status_code}</p>
    """

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)